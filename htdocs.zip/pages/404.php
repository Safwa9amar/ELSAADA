<link rel="stylesheet" href="./css/404.css">

<div class="container">
   <div class="msg">
   <h1>404</h1>
    <h2>page not found</h2>
   </div>
</div>