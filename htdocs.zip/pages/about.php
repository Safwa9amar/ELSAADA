<link rel="stylesheet" type="text/css" href="./css/about.css" />
<div class="about">
  <div class="content-section">
    <h1>A Propos</h1>
    <div class="content">
      <h3>Comment se passe une agence immobilière</h3>
      <p>
        Une agence immobilière est dirigèe par un gèrant. Dans le cas
        d'une franchise,C'est le franchise qui gère l'unitè.Il est secondè
        par une èquipe de nègociateurs immobiliers ou agents
        commerciaux.Enfin,afin de tenir l'accueil, une personne est
        souvent chargèe de l'assistanat commercial.
      </p>
    </div>
    <div class="social">
      <li><i class="fa fa-facebook-square fa-2x"></i></li>
      <li><i class="fa fa-instagram fa-2x"></i></li>
      <li><i class="fa fa-twitter-square fa-2x"></i></li>
    </div>
  </div>
  <img src="./images/6.jpg" />
</div>