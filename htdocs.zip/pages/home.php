<link rel="stylesheet" href="./css/home.css">

<div class="home-wrapper">
    <div class="descpription">
        <!-- <img src="./images/logoBlack.svg" alt="logo"> -->
        <h1>Application Agence Immobiliere <br> Bienvenue chez nous</h1>
        <p>Trouver la maison de vos reves chez notre agence immobiliere
        </p>

    </div>

</div>
