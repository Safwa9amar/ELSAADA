<?php
     $upload_dir = "../admin/uploads/";
?>