<title>
    <?php
    if (isset($_GET['page'])) {
        echo $_GET['page'];
    } else {
        echo 'El Saada';
    }
    ?>
</title>


<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">


<!-- css roles -->
<link rel="stylesheet" href="./css/index.css">
<link rel="stylesheet" href="./css/nav.css">

<!-- favicon -->
<link rel="icon" href="./favicon.png" type="image/png">

<link href="https://fonts.googleapis.com/css2?family=Poppins&family=Roboto+Slab&display=swap" rel="stylesheet" />

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous" />