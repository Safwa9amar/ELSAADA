<?php
    $product_table = 'localtion';